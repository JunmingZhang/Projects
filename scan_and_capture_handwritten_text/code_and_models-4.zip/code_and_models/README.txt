Run the code using: python char_recognition.py [IMAGE]
For exampe: python char)recoginition.py sample_page_good.jpg